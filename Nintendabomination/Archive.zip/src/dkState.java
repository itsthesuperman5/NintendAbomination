import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.tiled.TiledMap;

/**
 * 
 */

/**
 * @author stephenwright
 *
 */
public class dkState extends BasicGameState {
	
	private int stateID;
	private TiledMap map;
	private Rectangle playerBound;
	private Rectangle[][] rect;
	private float pX, pY;
	private float playerVel, playerLift, climbVel;
	private grantSide player;
	private boolean[][] ground;
	private boolean[][] ladder;
	private Shape[] shape;
	private int shapeCount;
	private int mapX, mapY;
	private boolean jumping, right, left, crouched, moving, climbing;

	public dkState(int stateID)
	{
		this.stateID = stateID;
	}
	
	@Override
	public void init(GameContainer gc, StateBasedGame sbg)
			throws SlickException {
		// TODO Auto-generated method stub
		map = new TiledMap("res/dkLevel.tmx");
		player = new grantSide();
		jumping = false; right = true; left = false; crouched = false; moving = false; climbing = false;
		pX = 100;
		pY = 500;
		mapX = 0;
		mapY = 0;
		playerVel = 0.1f;
		climbVel = 0.1f;
		shapeCount = 0;
		gc.setMinimumLogicUpdateInterval(20);
		playerBound = new Rectangle(pX, pY, 16, 40);
		ground = new boolean[map.getWidth()][map.getHeight()];
		ladder = new boolean[map.getWidth()][map.getHeight()];
		rect = new Rectangle[map.getWidth()][map.getHeight()];
		shape = new Shape[10000];
		for (int x=0;x<map.getWidth();x++) 
		{
			for (int y=0;y<map.getHeight();y++)
			{
				int tileID = map.getTileId(x, y, 1);
				String value = map.getTileProperty(tileID, "blocked", "false");
				String value1 = map.getTileProperty(tileID, "ladder", "false");
				if ("true".equals(value))
				{
					ground[x][y] = true;
					rect[x][y] = new Rectangle((float)(x*32), (float)(y*32), map.getTileWidth(), map.getTileHeight());
					shape[shapeCount] = rect[x][y];
					shapeCount++;
				}
				if("true".equals(value1))
				{
					ladder[x][y] = true;
				}
			}
		}
	}

	@Override
	public void render(GameContainer gc, StateBasedGame sbg, Graphics g)
			throws SlickException {
		// TODO Auto-generated method stub
		map.render(0, 0, 0);
		if(climbing && moving)
		{
			player.getClimbing().draw(playerBound.getX()-32+mapX, playerBound.getY()-26+mapY);
		}
		else if(climbing)
		{
			player.getLadder().draw(playerBound.getX()-32+mapX, playerBound.getY()-26+mapY);
		}
		else if(jumping && right)
		{
			player.getJumpRight().draw(playerBound.getX()-32+mapX, playerBound.getY()-26+mapY);
		}
		else if(jumping && left)
		{
			player.getJumpLeft().draw(playerBound.getX()-32+mapX, playerBound.getY()-26+mapY);
		}
		else if(crouched && right)
		{
			player.getCrouchRight().draw(playerBound.getX()-32+mapX, playerBound.getY()-26+mapY);
		}
		else if(crouched && left)
		{
			player.getCrouchLeft().draw(playerBound.getX()-32+mapX, playerBound.getY()-26+mapY);
		}
		else if(!moving && right)
		{
			player.getStandRight().draw(playerBound.getX()-32+mapX, playerBound.getY()-26+mapY);
		}
		else if(!moving && left)
		{
			player.getStandLeft().draw(playerBound.getX()-32+mapX, playerBound.getY()-26+mapY);
		}
		else if(moving && right)
		{
			player.getRunRight().draw((playerBound.getX()-32)+mapX, playerBound.getY()-26+mapY);
		}
		else if(moving && left)
		{
			player.getRunLeft().draw((playerBound.getX()-32)+mapX, playerBound.getY()-26+mapY);
		}
	}

	@Override
	public void update(GameContainer gc, StateBasedGame sbg, int delta)
			throws SlickException {
		// TODO Auto-generated method stub
		float hip = playerVel * delta;
		float pip = playerLift * delta;
		float cip = climbVel * delta;
		if(!jumping && !collides(playerBound, shape) && !climbing)
		{
			playerBound.setY(playerBound.getY()+0.3f*delta);
		}
		Input input = gc.getInput();
		if(input.isKeyPressed(Input.KEY_UP) && !jumping && !climbing && 
				ladder[(int)playerBound.getCenterX()/32][(int)(playerBound.getCenterY()/32)])
		{
			climbing = true;
		}
		if(climbing)
		{
			if(input.isKeyDown(Input.KEY_UP) && ladder[(int)playerBound.getCenterX()/32][(int)((playerBound.getCenterY())/32)])
			{
				moving = true;
				playerBound.setY(playerBound.getY() - cip);
			}
			else if(input.isKeyDown(Input.KEY_DOWN) && ladder[(int)playerBound.getCenterX()/32][(int)((playerBound.getCenterY()+32)/32)])
			{
				moving = true;
				playerBound.setY(playerBound.getY() + cip);
			}
			else
				moving = false;
		}
		
		if(input.isKeyDown(Input.KEY_DOWN))
		{
			moving = false;
			crouched = true;
		}
		else
			crouched = false;
		if(jumping && playerLift >= 0)
		{
			playerBound.setY(playerBound.getY()-pip);
			playerLift -= 0.04f;
		}
		else if(jumping && playerLift < 0)
		{
			if (ground[(int)playerBound.getX()/32][((int)(((playerBound.getY()+player.getStandRight().getHeight())-(pip))/32))] != true)
			{
				playerBound.setY(playerBound.getY()-pip);
				playerLift -= 0.04f;		
			}
			else
			{
				System.out.println("not jumping");
				jumping = false;		
			}
		}
		if(input.isKeyPressed(Input.KEY_SPACE) && !jumping)
		{
			jumping = true;
			climbing = false;
			playerLift = 0.6f;
		}
		if(input.isKeyDown(Input.KEY_RIGHT) && !crouched && !climbing)
		{
			left = false;
			right = true;
			moving = true;
			playerBound.setX(playerBound.getX()+hip);
		}
		else if(input.isKeyDown(Input.KEY_LEFT) && !crouched && !climbing && playerBound.getX() > -10)
		{
			right = false;
			left = true;
			moving = true;
			playerBound.setX(playerBound.getX()-hip);
		}
		else if(!climbing)
			moving = false;
	}

	@Override
	public int getID() {
		// TODO Auto-generated method stub
		return stateID;
	}
	
	public boolean collides(Rectangle a, Shape[] b)
	{
		boolean hit = false;
		for(int i=0; i < shapeCount; i++)
		{
			if(a.intersects(b[i]))
				hit = true;
		}
		return hit;
	}

}
